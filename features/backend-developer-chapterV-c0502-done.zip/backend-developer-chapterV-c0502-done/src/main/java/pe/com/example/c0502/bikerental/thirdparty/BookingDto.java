package pe.com.example.c0502.bikerental.thirdparty;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * En esta clase se define las propiedas con la se interactura entre la aplicación y el modelo de datos.
 * Class: BookingDto
 * para la creación del modelo de datos tomar en consideración que se esta trabajando con el schema "cibertec".
 */
@Entity
@Table(name = "Booking", schema = "cibertec")
public class BookingDto implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = -4357742218022307678L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "booking_id", columnDefinition = "")
  private int bookingId;

  @Column(name = "is_canceled")
  private boolean canceled;

  @Column(name = "created_at")
  private LocalDateTime createdAt;

  @Column(name = "user_id")
  private String userId;

  @Column(name = "bike_id")
  private String bikeId;

  /**
   * @return the bookingId
   */
  public int getBookingId() {
    return bookingId;
  }

  /**
   * @return the bikeId
   */
  public String getBikeId() {
    return bikeId;
  }

  /**
   * @param bikeId the bikeId to set
   */
  public void setBikeId(String bikeId) {
    this.bikeId = bikeId;
  }

  /**
   * @return the userId
   */
  public String getUserId() {
    return userId;
  }

  /**
   * @param userId the userId to set
   */
  public void setUserId(String userId) {
    this.userId = userId;
  }

  /**
   * @return the createdAt
   */
  public LocalDateTime getCreatedAt() {
    return createdAt;
  }

  /**
   * @param createdAt the createdAt to set
   */
  public void setCreatedAt(LocalDateTime createdAt) {
    this.createdAt = createdAt;
  }

  /**
   * @return the canceled
   */
  public boolean isCanceled() {
    return canceled;
  }

  /**
   * @param canceled the canceled to set
   */
  public void setCanceled(boolean canceled) {
    this.canceled = canceled;
  }

  /**
   * @param bookingId the bookingId to set
   */
  public void setBookingId(int bookingId) {
    this.bookingId = bookingId;
  }

}