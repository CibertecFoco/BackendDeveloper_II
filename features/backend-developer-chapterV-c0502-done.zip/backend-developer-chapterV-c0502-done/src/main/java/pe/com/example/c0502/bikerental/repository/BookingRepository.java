package pe.com.example.c0502.bikerental.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import pe.com.example.c0502.bikerental.thirdparty.BookingDto;

@Repository
public interface BookingRepository extends CrudRepository<BookingDto, String> {

}