package pe.com.example.c0502.bikerental.business.fn03;

import java.sql.SQLException;
import org.springframework.stereotype.Service;
import pe.com.example.c0502.bikerental.models.api.fn03.request.BikeBookingRequest;

@Service
public class BookingServiceImpl implements BookingService {

  private final BookingSender sender;

  public BookingServiceImpl(BookingSender sender) {
    this.sender = sender;
  }

  @Override
  public void createBikeBooking(BikeBookingRequest payload) throws SQLException {
    sender.createBookingAndDetails(payload);

  }

}