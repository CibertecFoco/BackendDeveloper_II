package pe.com.example.c0502.bikerental.business.fn03;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import pe.com.example.c0502.bikerental.models.api.fn03.request.BikeBookingRequest;
import pe.com.example.c0502.bikerental.repository.BookingRepository;
import pe.com.example.c0502.bikerental.thirdparty.BookingDto;

@Component
public class BookingSender {

  private static final Logger log = LoggerFactory.getLogger(BookingSender.class);

  private BookingRepository repository;

  public BookingSender(BookingRepository repository) {
    this.repository = repository;
  }

  /**
   * Este método hará uso de BookingRepository para realizar los cambios en la base de datos.
   *
   * @param payload BikeBookingRequest
   * @throws SQLException si se produce una excepción cuando se comunique con la base de datos.
   */
  public void createBookingAndDetails(BikeBookingRequest payload) throws DataAccessException {
    LocalDateTime createAt = LocalDateTime.now(ZoneId.of("America/Lima"));
    BookingDto dto = new BookingDto();

    dto.setCreatedAt(createAt);
    dto.setUserId(payload.getUserId());
    dto.setBikeId(payload.getBike().getCode());
    repository.save(dto);

  }

}
