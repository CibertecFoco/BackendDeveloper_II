package pe.com.example.c0502.bikerental.business.fn03;

import java.sql.SQLException;
import pe.com.example.c0502.bikerental.models.api.fn03.request.BikeBookingRequest;

/**
 * Interfaz que nos permite integranos a la aplicación.
 * se define el método que nos permitirá create una nueva reserva de una bicicleta.
 */
public interface BookingService {

/**
 * Este método en su implementación llamara a BookingSender quien a su vez realizará la transacción en la base de datos
 * con la ayuda de BookingResponsitory que extiende de CrudRepository que es con su implementación hace el manejo de las transacción con la Base de datos.
 *
 * @param payload Datos de la renta
 * @throws SQLException si se produce una excepción al transaccionar con la BD.
 */
  void createBikeBooking(BikeBookingRequest payload) throws SQLException;

}