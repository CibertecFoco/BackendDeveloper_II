Spring Data - JPA
=================

Caso:
------------
Para este laboratorio se hará la implementación del registro de una reserva de una bicible a través del uso de Spring Data y JPA.

> #### Revisar los comentarios del código para más detalles.

Se hará uso del siguiente dependencias:

##### Requeridos

- spring boot web
- spring data jpa
- mssql-server (version equivalente al jdk)

##### Opcionales

- spring boot validation (javax.validation)
- spring boot actuator

> Las credenciales establecidad para el acceso a la base de datos solo están disponibles hasta el 2020-08-15, despúes de dicha fecha se tendrá que habilitar un nuevo componente AzureSQL para demostrar el laboratorio o en su defecto hacerlo con un base de datos en local.

----

Pasos:
------

- Para configurar el Datasource y aprovechar la autoconfiguración que realiza spring boot, debemos de definir la siguiente configuración en *application.yml*.
```yml
spring:
  datasource:
    initialization-mode: always
    schema: classpath:scripts/schema-mssql.sql
    data: classpath:scripts/data-mssql.sql
    name: BIKE_RENTAL
    url: jdbc:sqlserver://sqlservercvd01.database.windows.net:1433;database=BIKE_RENTAL;encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;
    username: cvaldezc@sqlservercvd01
    password: L1M42020@
    driver-class-name: com.microsoft.sqlserver.jdbc.SQLServerDriver
```

- Definir las clases model de los packages *models* y *thirdparty*, necesarios para la recepción de los datos, cuando se realice la petición http y se guarde los datos en la BD.
- Para hacer uso de **CrudRepository** se de habilitar la anotación @EnableJpaRepositories de preferencia en una clase de configuración o en su defecto hacerlo en la clase principal. ver *pe.com.example.c0502*.
- Realizar la definición de la interfaz **BookingRespository.java** y la clase **BookingSender.java** estos objetos realizan las transacción con la base de datos.
- Implementar las clases necesarias para exponer la funcionalidad de creación de una reserva de bicicleta. **(DataJpaController.java)**

----

Pruebas:
--------

Se debe hacer uso del collection postman ubicado en *src/main/resources/postman*

