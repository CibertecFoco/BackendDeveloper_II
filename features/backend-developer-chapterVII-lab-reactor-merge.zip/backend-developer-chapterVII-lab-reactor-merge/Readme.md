Project Reactor
================


Opertator
---------

- merge

Caso:
-----

Para este laboratorio se realiza el consumo de dos métodos los cuales nos retorna una lista de cuentas de ahorros y una lista de cuentas maestras respectivamente. 

Los métodos que retornan las cuentas son de tipo Flux, para unir ambos llamados se hace uso del operador *.merge()*. 

Adicionalmente se realiza el consumo de un tercer método para poder consumir una lista de tarjetas del cliente, para lo cual se utiliza *.mergeWith()*.

Finalmente la clase principal OperatorApplication, muestra la suscripción y muestra los datos casteados a una clase padre (Product).
