package pe.com.example.reactor.business;

import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Account;
import pe.com.example.reactor.model.Product;
import reactor.core.publisher.Flux;

@Service
public class TransformService {

  private AccountService accounts;
  private CardService cards;

  public TransformService(AccountService accounts, CardService cards) {
    this.accounts = accounts;
    this.cards = cards;
  }

  private Flux<Account> getTwoSourceAccounts(String ClientId) {
    return Flux.merge(accounts.getSavingAccounts(ClientId), accounts.getMasterAccounts(ClientId));
        // .filter(
        //     (account) -> (account.getAvailableAmount().compareTo(BigDecimal.valueOf(500L)) >= 0));
  }

  public Flux<Product> getAllProduct(String clientId) {
    return getTwoSourceAccounts(clientId)
        .map((account) -> (Product) account)
        .mergeWith(
            cards.getAllAccounts(clientId))
            .cast(Product.class);
              // or .map(card -> (Product) card));
  }

}
