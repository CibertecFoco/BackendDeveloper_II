package pe.com.example.reactor.model;

public class Client {

  private String clientId;
  private String name;
  private String gender;
  private String segment;
  private boolean active;

  /**
   * @return the clientId
   */
  public String getClientId() {
    return clientId;
  }

  /**
   * @return the active
   */
  public boolean isActive() {
    return active;
  }

  /**
   * @param active the active to set
   */
  public void setActive(boolean active) {
    this.active = active;
  }

  /**
   * @return the segment
   */
  public String getSegment() {
    return segment;
  }

  /**
   * @param segment the segment to set
   */
  public void setSegment(String segment) {
    this.segment = segment;
  }

  /**
   * @return the gender
   */
  public String getGender() {
    return gender;
  }

  /**
   * @param gender the gender to set
   */
  public void setGender(String gender) {
    this.gender = gender;
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * @param clientId the clientId to set
   */
  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  @Override
  public String toString() {
    return String.format("[clientId=%s, name=%s, gender=%s, segment=%s, active=%b]",
        this.getClientId(), this.getName(), this.getGender(), this.getSegment(), this.isActive());
  }

}
