package pe.com.example.reactor.business;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Account;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

/**
 * ProductService
 */
@Service
public class AccountService {

  private static final Logger log = LoggerFactory.getLogger(Account.class);

  public Flux<Account> getSavingAccounts(String clientId) {
    log.info("----------------------------------------------");
    return Flux.<Account>fromIterable(getAccounts(clientId, "saving"))
        .publishOn(Schedulers.newElastic("saving"));
    //.log();
  }

  public Flux<Account> getMasterAccounts(String clientId) {
    log.info("----------------------------------------------");
    return Flux.<Account>fromIterable(getAccounts(clientId, "master"))
        .publishOn(Schedulers.newElastic("master"));
    //.log();
  }

  public List<Account> getAccounts(String clientId, String type) {
    List<Account> accounts = new LinkedList<>();
    int nAccount = new Random().nextInt(12);
    log.info("[account] generate account {} size {}", type, nAccount);
     while ((nAccount--) > 0) {
       accounts.add(generateAccount(type));
       log.info("add account");
     }
    return accounts;
  }

  public Account generateAccount(String type) {
    Account account = new Account();
    int accountid = Math.abs(new Random().nextInt());
    account.setReferenceId(String.format("1910032%d01", accountid));
    account.setAccountFormattedId(String.format("191-0032%d-0-1", accountid));
    account.setName(type);
    account.setAccountingAmount(BigDecimal.valueOf(new Random().nextDouble() * 1000));
    account.setAvailableAmount(BigDecimal.valueOf(new Random().nextDouble() * 1000));
    return account;
  }
}