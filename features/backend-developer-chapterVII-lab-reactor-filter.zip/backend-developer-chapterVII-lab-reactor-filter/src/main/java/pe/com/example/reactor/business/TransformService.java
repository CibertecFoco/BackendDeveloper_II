package pe.com.example.reactor.business;

import java.math.BigDecimal;
import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Account;
import reactor.core.publisher.Flux;

@Service
public class TransformService {

  private AccountService accounts;

  public TransformService(AccountService accounts, ClientService client) {
    this.accounts = accounts;
  }

  public Flux<Account> getTwoSourceAccounts(String ClientId) {
    return Flux.merge(accounts.getSavingAccounts(ClientId), accounts.getMasterAccounts(ClientId))
    .filter((account) -> (account.getAvailableAmount().compareTo(BigDecimal.valueOf(500L)) >= 0));
  }

}
