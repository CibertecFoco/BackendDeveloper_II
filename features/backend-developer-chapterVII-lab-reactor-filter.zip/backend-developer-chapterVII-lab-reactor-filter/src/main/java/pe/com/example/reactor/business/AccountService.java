package pe.com.example.reactor.business;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Account;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

/**
 * ProductService
 */
@Service
public class AccountService {

  private static final Logger log = LoggerFactory.getLogger(Account.class);

  public Flux<Account> getMasterAccounts(String clientId) {
    log.info("----------------------------------------------");
    return Flux.<Account>fromIterable(getAccounts(clientId))
        .publishOn(Schedulers.newElastic("elastic-master")).log();
  }

  public Flux<Account> getSavingAccounts(String clientId) {
    log.info("----------------------------------------------");
    return Flux.<Account>fromIterable(getAccounts(clientId))
        .publishOn(Schedulers.newElastic("elastic-saving")).log();
  }

  public List<Account> getAccounts(String clientId) {
    List<Account> accounts = new LinkedList<>();
    int nAccount = new Random().nextInt(12);
    log.info("[account] generate account {} length", nAccount);
    while ((nAccount--) > 0) {
      accounts.add(generateAccount());
      log.info("add account");
    }
    return accounts;
  }

  public Account generateAccount() {
    Account account = new Account();
    account.setAccountId(String.format("191-0032%d-0-1", Math.abs(new Random().nextInt())));
    account.setName("Cuenta de Ahorros");
    account.setAccountingAmount(BigDecimal.valueOf(new Random().nextDouble() * 1000));
    account.setAvailableAmount(BigDecimal.valueOf(new Random().nextDouble() * 1000));
    return account;
  }
}
