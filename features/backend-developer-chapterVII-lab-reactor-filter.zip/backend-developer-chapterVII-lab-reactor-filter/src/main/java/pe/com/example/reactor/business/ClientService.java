package pe.com.example.reactor.business;

import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Client;

@Service
public class ClientService {

  public Client getClientDetails(String clientId) {
    return findById(clientId);
  }

  private Client findById(String clientId) {
    Client client = new Client();
    client.setClientId(clientId);
    client.setName("Alessando Rodriguez Cruz");
    client.setGender("M");
    client.setSegment("M1N");
    client.setActive(true);
    return client;
  }
}