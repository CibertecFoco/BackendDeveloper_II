Project Reactor
==============

Opertator:
----------

### Filter

##### Caso:

Para este laboratorio se realiza una consulta de dos servicios (Mock) que listaran cuentas de ahorros y cuentas maestras respectivamente.
Obtenidas las cuentas estas serán eminitas una por una a través del operador rectivo proveido por Project Reactor - Flux.
Acada cuenta emitada se le realiza un filtro para validar el cumplimiento de que la cuenta cuente con un saldo disponible minimo disponible de 500.

Finalmente la clase principal *OperatorsApplication*, realizará una suscripción y solo mostrará aquellas cuentas que cumplan con la condición anterior mencionada
