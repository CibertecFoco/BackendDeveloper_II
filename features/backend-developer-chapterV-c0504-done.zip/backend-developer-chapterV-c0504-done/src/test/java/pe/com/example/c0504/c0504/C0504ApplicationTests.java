package pe.com.example.c0504.c0504;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C0504ApplicationTests {

	@Test
	void contextLoads() {
	}

}
