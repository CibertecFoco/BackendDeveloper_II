package pe.com.example.c0504.business.fn09;

import java.util.List;
import org.springframework.stereotype.Service;
import pe.com.example.c0504.thirdparty.mongodb.StationDocument;

/**
 * Clase implementadora de la lógica necesario para poder exponer los datos de las estaciones
 * almacenada sobre el collection de mongoDB.
 */
@Service
public class StationServiceImpl implements StationService {

  private StationSender sender;

  public StationServiceImpl(StationSender sender) {
    this.sender = sender;
  }

  @Override
  public StationDocument getStationByStationId(String stationId) {
    return sender.getStationById(stationId);
  }

  @Override
  public List<StationDocument> getStationAll() {
    return sender.getAllStation();
  }

}
