package pe.com.example.c0504.business.fn09;

import java.util.List;
import pe.com.example.c0504.thirdparty.mongodb.StationDocument;


public interface StationService {

  /**
   * método para consultar las bicicletas por medio de un identificador de estación.
   *
   * @param stationId
   * @return
   */
  StationDocument getStationByStationId(String stationId);


  /**
   * método para obtener todas las estaciones con el detalle de bicicletas y sus cantidades.
   *
   * @return
   */
  List<StationDocument> getStationAll();

}
