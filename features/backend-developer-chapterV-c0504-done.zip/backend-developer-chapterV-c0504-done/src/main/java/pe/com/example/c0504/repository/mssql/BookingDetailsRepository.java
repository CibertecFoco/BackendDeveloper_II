package pe.com.example.c0504.repository.mssql;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.com.example.c0504.thirdparty.mssql.BookingDetailsDto;

@Repository
public interface BookingDetailsRepository extends JpaRepository<BookingDetailsDto, Integer> {

}