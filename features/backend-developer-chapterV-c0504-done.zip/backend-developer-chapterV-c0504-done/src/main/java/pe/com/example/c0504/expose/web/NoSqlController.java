package pe.com.example.c0504.expose.web;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import pe.com.example.c0504.business.fn03.BookingService;
import pe.com.example.c0504.business.fn09.StationService;
import pe.com.example.c0504.models.api.fn03.BookingRequest;
import pe.com.example.c0504.thirdparty.mongodb.StationDocument;

/**
 * Este controlador expone dos funcionalidad de negocio.
 *
 * - Creación y actualización de estado del alquiler a completado. - Listado de de bicicletas y con
 * sus cantidades por identidicador de estación o el total.
 */
@RestController
@RequestMapping("/bike-rental/mvc/v1")
public class NoSqlController {

  private final BookingService bookingService;
  private final StationService stationService;

  public NoSqlController(BookingService bookingService, StationService stationService) {
    this.bookingService = bookingService;
    this.stationService = stationService;
  }

  /**
   * Creación de un alquiler de bicicleta.
   *
   * @param payload
   * @throws Exception
   */
  @PostMapping(value = "/booking", produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.CREATED)
  public void createBikeBooking(@RequestBody BookingRequest payload) throws Exception {
    bookingService.createBikeBooking(payload);
  }

  /**
   * Actualizar el estado de un alquiler de bicicleta.
   *
   * @param bookingId
   * @throws Exception
   */
  @PatchMapping(value = "/booking/{bookingId}", produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void completedBikeBooking(@PathVariable("bookingId") Integer bookingId) throws Exception {
    bookingService.completeBikeBooking(bookingId);
  }

  /**
   * Consultar las cantidad de bicicletas por un indentificador de estación.
   *
   * @param stationId
   * @return StationDocument
   */
  @GetMapping(value = "/station/{stationId}", produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.OK)
  public StationDocument getStationById(@PathVariable("stationId") String stationId) {
    return stationService.getStationByStationId(stationId);
  }


  /**
   * Listar todas las estaciones con las cantidades de bicicletas que se encuentran disponibles por
   * cada estación.
   *
   * @return List<StationDocument>
   */
  @GetMapping(value = "/station", produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.OK)
  public List<StationDocument> getStationAll() {
    return stationService.getStationAll();
  }

}
