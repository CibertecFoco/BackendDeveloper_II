package pe.com.example.c0504.business.fn03;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import pe.com.example.c0504.models.api.fn03.BookingRequest;
import pe.com.example.c0504.thirdparty.mongodb.BikeDocument;
import pe.com.example.c0504.thirdparty.mongodb.InventoryStatus;
import pe.com.example.c0504.thirdparty.mongodb.StationDocument;
import pe.com.example.c0504.thirdparty.mssql.BookingDetailsDto;
import pe.com.example.c0504.thirdparty.mssql.BookingDto;
import pe.com.example.c0504.repository.mongodb.StationRepository;
import pe.com.example.c0504.repository.mssql.BookingDetailsRepository;
import pe.com.example.c0504.repository.mssql.BookingRepository;

/**
 * Clase que nos ayuda con las transacciones sobre la base de datos. Para la desarrollo se habilitan
 * dos operaciones crear el alquiler y completar el alquiler. Esto con el fin de mantener un
 * inventario actualizado en el collection de mongodb.
 *
 * Adicional para el caso de mongo se habilita las operaciones por Repositories de spring data y
 * MongoOperations que es una capa más personalizada para acceder a los datos de mongodb.
 */
@Component
public class BookingSender {

  private static final Logger log = LoggerFactory.getLogger(BookingSender.class);

  private final BookingRepository bookingRepository;
  private final BookingDetailsRepository bookingDetailsRepository;
  private final StationRepository stationRepository;

  /**
   * constructor.
   *
   * @param bookingRepository
   * @param bookingDetailsRepository
   * @param stationRepository
   */
  public BookingSender(BookingRepository bookingRepository, BookingDetailsRepository bookingDetailsRepository,
      StationRepository stationRepository) {
    this.bookingRepository = bookingRepository;
    this.stationRepository = stationRepository;
    this.bookingDetailsRepository = bookingDetailsRepository;
  }


  /**
   * método que permite realizar los alquieres de las bicicleas, realizando las transacciones en
   * AzureSQL y posteriormente actualizando un inventario en un collection en mongoDB. decrementando
   * la cantidad de la bicicleta en uno a la estación origen del alquiler.
   *
   * Para el caso se almacen tanto el la cabecera y el detalle del alquiler. (AzureSQL)
   *
   * @param payload
   */
  public void createBikeBooking(BookingRequest payload) throws Exception {
    BookingDto booking = new BookingDto();
    booking.setBikeId(payload.getBike().getCode());
    booking.setUserId(payload.getUserId());
    final LocalDateTime createAt = getSystemDateTime();
    booking.setCreateAt(createAt);

    BookingDto bookingSaved = bookingRepository.save(booking);

    BookingDetailsDto details = new BookingDetailsDto();
    details.setBookingId(bookingSaved.getBookingId());
    details.setDestinationStationId(payload.getDestination().getStation().getCode());
    details.setOriginStationId(payload.getOrigin().getStation().getCode());
    details.setStartDate(createAt);

    BookingDetailsDto detailsSaved = bookingDetailsRepository.save(details);

    updateInventory(bookingSaved, detailsSaved, InventoryStatus.DECREMENT);
  }

  /**
   * método que permite la actualización del estado del alquiler de las bicicletas a estado
   * completado. luego actualiza el inventario en la collection de mongoDB, incrementando la cantidad
   * de la bicicleta en la estación destino.
   *
   * @param bookingId
   * @throws Exception
   */
  public void completeBikeBooking(int bookingId) throws Exception {
    Optional<BookingDto> bookingDto = findBookingById(bookingId);
    if (bookingDto.isPresent()) {
      BookingDto booking = bookingDto.get();
      LocalDateTime completedDate = getSystemDateTime();
      booking.setCompletedDate(completedDate);
      booking.setCompleted(true);

      BookingDto bookingUpdated = bookingRepository.save(booking);

      Optional<BookingDetailsDto> opDetails = bookingDetailsRepository.findById(bookingUpdated.getBookingId());
      if (opDetails.isPresent()) {
        BookingDetailsDto details = opDetails.get();
        details.setEndDate(completedDate);

        BookingDetailsDto detailsUpdated = bookingDetailsRepository.save(details);

        updateInventory(bookingUpdated, detailsUpdated, InventoryStatus.INCREMENT);
      }
    }
  }

  /**
   * método que nos permite buscar un alquiler en AzureSQL.
   *
   * @param bookingId
   * @return
   * @throws Exception
   */
  private Optional<BookingDto> findBookingById(int bookingId) throws Exception {
    log.info("[by find bookingId] {}", bookingId);
    if (bookingId < 0) {
      throw new Exception("[find booking] BookingId not valid");
    }
    return bookingRepository.findById(bookingId);
  }

  /**
   * método para obtener la fecha y hora del systema actual.
   *
   * @return
   */
  private LocalDateTime getSystemDateTime() {
    return LocalDateTime.now(ZoneId.of("America/Lima"));
  }

  /**
   * método que realiza el mantenimiento de las cantidad de las bicicleas entrantes y salientes.
   *
   * @param booking
   * @param bookingDetails
   * @param status
   */
  private void updateInventory(BookingDto booking, BookingDetailsDto bookingDetails, InventoryStatus status)
      throws Exception {
    if (booking == null || bookingDetails == null) {
      throw new Exception("Update Inventory, Booking or BookingDetails are null.");
    }
    StationDocument station = stationRepository.findByStationId(bookingDetails.getDestinationStationId());
    log.info(" size bikes {}", station.getBikes().size());
    for (BikeDocument bike : station.getBikes()) {
      log.info("[bikes] {}", bike.getBikeId());
      if (booking.getBikeId().equals(bike.getBikeId())) {

        bike.setQuantity(incrementOrDecrement(bike.getQuantity(), status));
        break;
      }
    }

    log.info("[station] {}", station);
    // realiza la modificación en la colección.
    stationRepository.save(station);

    /**
     * También se puede relizar el update por medio de MongoOperations con las siguientes 3 lineas.
     *
     * Query query =
     * Query.query(Criteria.where("stationId").is(bookingDetails.getDestinationStationId())); Update
     * update = Update.update("bikes", station.getBikes().toArray()); mongoOps.upsert(query, update,
     * StationDocument.class);
     */

  }

  /**
   * método opera las cantidad de las bicicletas incrementando o decrementado su valor.
   *
   * @param quantity
   * @param status
   * @return int
   */
  private int incrementOrDecrement(int quantity, InventoryStatus status) {
    if (quantity == 0 && InventoryStatus.DECREMENT.compareTo(status) == 0) {
      return quantity;
    }

    if (InventoryStatus.DECREMENT.compareTo(status) == 0) {
      log.info("[bike] decrement in one {} - 1", quantity);
      return --quantity;
    } else if (InventoryStatus.INCREMENT.compareTo(status) == 0) {
      log.info("[bike] increment in one {} + 1", quantity);
      return ++quantity;
    }
    return quantity;
  }

}
