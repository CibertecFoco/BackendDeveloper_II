package pe.com.example.c0504.business.fn03;

import org.springframework.stereotype.Service;
import pe.com.example.c0504.models.api.fn03.BookingRequest;

/**
 * Class que implementa la lógica de negocio necesaría para procesar la creación de un alquiler de
 * bicicletas y actualizar el estado del alquiler a completado.
 */
@Service
public class BookingServiceImpl implements BookingService {

  private final BookingSender sender;

  public BookingServiceImpl(BookingSender sender) {
    this.sender = sender;
  }

  @Override
  public void createBikeBooking(BookingRequest payload) throws Exception {
    sender.createBikeBooking(payload);
  }

  @Override
  public void completeBikeBooking(int bookingId) throws Exception {
    sender.completeBikeBooking(bookingId);
  }

}
