package pe.com.example.c0504.config;

import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

/**
 * clase que configura la conexión hacia MongoBD.
 * Se habilita EnableMongoRepositories para hacer uso de la interfaz MongoRepository, como parte de la abstracción que provee Spring Data.
 */
@Configuration
@EnableJpaRepositories(basePackages = "pe.com.example.c0504.repository.mssql")
@EnableMongoRepositories(basePackages = "pe.com.example.c0504.repository.mongodb")
public class MongoConfig {

  /**
   * Fabrica de conexión para mongodb.
   *
   * @param properties lectura de datos desde el properties.
   * @return MongoClient
   */
  @Bean
  public MongoClient getMongoClient(MongoProperties properties) {
    return MongoClients.create(new ConnectionString(properties.getConnectionString()));
  }

  /**
   * método para exponer MongoTemplate para el uso de MongoOperations, capa personalizada para el aceceso de datos de mongodb.
   *
   * @param properties lectura de datos desde el properties
   * @return MongoTemplate
   */
  @Bean
  public MongoTemplate mongoTemplate(MongoProperties properties) {
    return new MongoTemplate(getMongoClient(properties), properties.getDatabase());
  }

}