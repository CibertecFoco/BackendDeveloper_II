package pe.com.example.c0504.business.fn03;

import pe.com.example.c0504.models.api.fn03.BookingRequest;

public interface BookingService {

  /**
   * método que crea un alquiler de bicicletas, interactua con AzureSQL y MongoDb.
   * @param payload {@ BookingRequest}
   * @throws Exception
   */
  void createBikeBooking(BookingRequest payload) throws Exception;

  /**
   * método para cambiar el estado de un alquiler a completado, realiza modificaciones sobre AzureSQL y MongoDB
   * @param bookingId int
   * @throws Exception
   */
  void completeBikeBooking(int bookingId) throws Exception;

}