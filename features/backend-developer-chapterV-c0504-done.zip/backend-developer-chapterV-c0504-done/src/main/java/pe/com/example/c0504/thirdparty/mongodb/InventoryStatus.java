package pe.com.example.c0504.thirdparty.mongodb;

public enum InventoryStatus {

  INCREMENT,
  DECREMENT

}