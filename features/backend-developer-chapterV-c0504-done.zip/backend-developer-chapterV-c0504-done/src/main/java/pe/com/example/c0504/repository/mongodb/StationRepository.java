package pe.com.example.c0504.repository.mongodb;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import pe.com.example.c0504.thirdparty.mongodb.StationDocument;

@Repository
public interface StationRepository extends MongoRepository<StationDocument, String> {

  StationDocument findByStationId(String stationId);

}