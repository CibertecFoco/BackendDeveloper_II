package pe.com.example.c0504.repository.mssql;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.com.example.c0504.thirdparty.mssql.BookingDto;

@Repository
public interface BookingRepository extends JpaRepository<BookingDto, Integer> {

}