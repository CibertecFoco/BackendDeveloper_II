DROP TABLE IF EXISTS CIBERTEC.DetailStations;
DROP TABLE IF EXISTS CIBERTEC.rental_details;
DROP TABLE IF EXISTS CIBERTEC.RentalDetails;
DROP TABLE IF EXISTS CIBERTEC.Station;
DROP TABLE IF EXISTS CIBERTEC.Booking;
DROP TABLE IF EXISTS CIBERTEC.Bike;
DROP TABLE IF EXISTS CIBERTEC.[User];
DROP TABLE IF EXISTS CIBERTEC.Person;

-- DROP SCHEMA [CIBERTEC];

IF NOT EXISTS (SELECT 0 FROM INFORMATION_SCHEMATA WHERE SCHEMA_NAME = 'CIBERTEC')
  BEGIN
    EXEC ('CREATE SCHEMA CIBERTEC')
  END;

CREATE TABLE CIBERTEC.Person (
    person_id VARCHAR(5) NOT NULL,
    first_name VARCHAR(60) NOT NULL,
    last_name VARCHAR(40) NOT NULL,
    is_active BIT NOT NULL,
    PRIMARY KEY (person_id)
);

CREATE TABLE CIBERTEC.[User] (
    [user_id] VARCHAR(5) NOT NULL,
    email VARCHAR(50) NOT NULL,
    passwd VARCHAR(15) NOT NULL,
    person_id VARCHAR(5) NOT NULL,
    is_active BIT NOT NULL,
    PRIMARY KEY (user_id),
    UNIQUE (email)
);

CREATE TABLE CIBERTEC.Booking (
    booking_id int IDENTITY(1,1) NOT NULL,
    is_canceled BIT NOT NULL,
    created_at datetime NOT NULL,
    user_id VARCHAR(5) NOT NULL,
    bike_id VARCHAR(5) NOT NULL,
    is_completed BIT NULL,
    date_completed DATETIME NULL
    PRIMARY KEY (booking_id)
);

CREATE TABLE CIBERTEC.Station (
    station_id VARCHAR(5) NOT NULL,
    name VARCHAR(60) NOT NULL,
    location VARCHAR(50) NOT NULL,
    is_active BIT NOT NULL,
    PRIMARY KEY (station_id)
);

CREATE TABLE CIBERTEC.Bike (
    bike_id VARCHAR(5) NOT NULL,
    type VARCHAR(30) NOT NULL,
    brand VARCHAR(20) NOT NULL,
    price_by_minute DECIMAL NOT NULL,
    is_active BIT NOT NULL,
    PRIMARY KEY (bike_id)
);

CREATE TABLE CIBERTEC.rental_details (
    booking_id INT NOT NULL,
    origin_station_id VARCHAR(5) NOT NULL,
    destination_station_id VARCHAR(5) NOT NULL,
    start_date datetime NOT NULL,
    end_date datetime
);

CREATE TABLE CIBERTEC.DetailStations (
    station_id VARCHAR(5) NOT NULL,
    bike_id VARCHAR(5) NOT NULL,
    quantity INT NOT NULL,
    is_active BIT NOT NULL
);

ALTER TABLE [CIBERTEC].[User]
  ADD FOREIGN KEY (person_id) REFERENCES [CIBERTEC].Person(person_id);
ALTER TABLE [CIBERTEC].Booking
  ADD FOREIGN KEY (user_id) REFERENCES [CIBERTEC].[User](user_id);
ALTER TABLE [CIBERTEC].Booking
  ADD FOREIGN KEY (bike_id) REFERENCES [CIBERTEC].Bike(bike_id);
ALTER TABLE [CIBERTEC].rental_details
  ADD FOREIGN KEY (booking_id) REFERENCES [CIBERTEC].Booking(booking_id);
ALTER TABLE [CIBERTEC].rental_details
  ADD FOREIGN KEY (origin_station_id) REFERENCES [CIBERTEC].Station(station_id);
ALTER TABLE [CIBERTEC].rental_details
  ADD FOREIGN KEY (destination_station_id) REFERENCES [CIBERTEC].Station(station_id);
ALTER TABLE [CIBERTEC].DetailStations
  ADD FOREIGN KEY (station_id) REFERENCES [CIBERTEC].Station(station_id);
ALTER TABLE [CIBERTEC].DetailStations
  ADD FOREIGN KEY (bike_id) REFERENCES [CIBERTEC].Bike(bike_id);

SET IDENTITY_INSERT CIBERTEC.Booking ON;
