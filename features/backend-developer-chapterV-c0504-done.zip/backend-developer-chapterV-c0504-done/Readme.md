Spring Data MongoDB
==================

Caso:
------
Para esté caso de laboratorio, se realizará la implementanción para mantener un inventario de las cantidades de las bicicletas por cada estación, este inventario será almacenada en un collection en mongodb. Así mismo tambien se hace uso de AzureSQL para persister los alquileres.

Cada vez que se realice un alquiler de una bicicleta, está en background llamará a un método para decrementar la cantidad de la bicicleta en uno (1) en la estación origin.
Cuando se realice el completado del alquiler (actualización de un flag y fecha de termino del alquiler), donde se incremente la cantidad de la bicicleta en uno (1) en la estación destino.

#### Dependencias

##### Requerido:

- spring boot web
- spring boot data jpa
- spring boot data mongodb
- mssql-jdbc

##### Opcional:

- spring boot actuator
- spring boot devtools

> Las credenciales establecidad para el acceso a la base de datos solo están disponibles hasta el 2020-08-15, despúes de dicha fecha se tendrá que habilitar un nuevo componente AzureSQL para demostrar el laboratorio o en su defecto hacerlo con un base de datos en local.

----------

Pasos:
------

- Agregar las dependencias necesarias pom.xml 
- Realizar la configuración de conexión hacia la base de datos mongodb, para lo cual en el archivo **application.yml** se define una cadena de conexión y el nombre de la base de datos. Definir el Bean como se define en el archivo *MongoConfig.java*.
- Lo siguiente es definir los modelos de las entidades y Documents como se define en el package **pe.com.example.c0504.thirdparty.mongodb**.
- Ahora se tiene que definir las interfaces para el uso de **Repositories** como parte de la abstracción que provee Spring Data, revisar el package *pe.com.example.c0504.repository.mongodb*.
- Definir la lógica de la necesaria para definir la lógica del inventario como se muestra en el package **pe.com.example.c0504.business.fn03**  en la clase *BookingSender.java*
- Así mismo también se debe definir la lógica para realizar la consulta hacia mongodb, para poder poder obtener la cantidad de bicicletas por cada estación, tambien hacer la consulta por medidio del identificador de cada estación.
- Para terminar en la clase principal package **pe.com.example.c0504** clase **MongoDbApplication.java** se debe definir un método que realice una carga inicial en el collection de la base de datos, revisar el detalle dentro de la clase, y el archivo de datos en la siguiente ruta **/src/main/resources/scripts/stations-init.json**.


-------


Pruebas:
---------

Las pruebas se pueden realiazar desde el *collection postman*, en la ruta */src/main/resources/postman/*.


