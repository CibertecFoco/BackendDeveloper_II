-- init load table person

INSERT INTO PERSON(person_id, first_name, last_name, is_active)
  VALUES('P0001','Christian','Valdez', true);
INSERT INTO PERSON(person_id, first_name, last_name, is_active)
  VALUES('P0002','Carolina','Paivva', true);
INSERT INTO PERSON(person_id, first_name, last_name, is_active)
  VALUES('P0003','Stephanie','Calderon', true);

-- init load table user
INSERT INTO USER(user_id, email, passwd, person_id, is_active)
  VALUES('U0001', 'cvaldez@outlook.com','1234','P0001',true);
INSERT INTO USER(user_id, email, passwd, person_id, is_active)
  VALUES('U0002', 'scalderon@outlook.com','1234','P0003',true);

-- init load table bike
INSERT INTO BIKE(bike_id, type, brand, price_by_minute, is_active)
  VALUES('K0001', 'Urban', 'Grand', 0.525, true);
INSERT INTO BIKE(bike_id, type, brand, price_by_minute, is_active)
  VALUES('K0002', 'Running', 'Grand', 1.452, true);
INSERT INTO BIKE(bike_id, type, brand, price_by_minute, is_active)
  VALUES('K0003', 'TriCycle', 'Grand', 0.8523, true);
INSERT INTO BIKE(bike_id, type, brand, price_by_minute, is_active)
  VALUES('K0004', 'Electric Bike', 'Grand', 2.525, true);

-- init load table booking
INSERT INTO BOOKING(booking_id, is_canceled, created_at, user_id, bike_id)
  VALUES(1,0,'2020-03-18 00:00:00', 'U0001', 'K0001');
INSERT INTO BOOKING(booking_id, is_canceled, created_at, user_id, bike_id)
  VALUES(2,0,'2020-03-18 00:00:00', 'U0001', 'K0001');
INSERT INTO BOOKING(booking_id, is_canceled, created_at, user_id, bike_id)
  VALUES(3,0,'2020-03-18 00:00:00','U0002', 'K0002');
INSERT INTO BOOKING(booking_id, is_canceled, created_at, user_id, bike_id)
  VALUES(4,0,'2020-03-18 00:00:00','U0002', 'K0004');

-- init load table station
INSERT INTO STATION(station_id, name, location, is_active)
  VALUES('S0001','Station Central','15.21554 -15.254842', true);
INSERT INTO STATION(station_id, name, location, is_active)
  VALUES('S0002','Central Park','43.21554 -16.254842', true);
INSERT INTO STATION(station_id, name, location, is_active)
  VALUES('S0003','Aranburú','78.21554 98.254842', true);
INSERT INTO STATION(station_id, name, location, is_active)
  VALUES('S0004','Rizzo','13.21554 345.254842', true);
INSERT INTO STATION(station_id, name, location, is_active)
  VALUES('S0005','Los Geranios','56.21554 23.254842', true);

-- init load table rental_details
INSERT INTO rental_details(booking_id, origin_station_id, destination_station_id, start_date, end_date)
  VALUES(1, 'S0001', 'S0003', '2020-03-21 00:00:00', null);
INSERT INTO rental_details(booking_id, origin_station_id, destination_station_id, start_date, end_date)
  VALUES(2, 'S0002', 'S0003', '2020-03-21 00:00:00', null);
INSERT INTO rental_details(booking_id, origin_station_id, destination_station_id, start_date, end_date)
  VALUES(3, 'S0003', 'S0001', '2020-03-21 00:00:00', null);
INSERT INTO rental_details(booking_id, origin_station_id, destination_station_id, start_date, end_date)
  VALUES(4, 'S0003', 'S0005', '2020-03-21 00:00:00', null);

-- init load  table DetailStations
INSERT INTO DETAILSTATIONS(station_id,bike_id,quantity,is_active)
  VALUES('S0001', 'K0001', 10, true);
INSERT INTO DETAILSTATIONS(station_id,bike_id,quantity,is_active)
    VALUES('S0001', 'K0003', 8, true);
INSERT INTO DETAILSTATIONS(station_id,bike_id,quantity,is_active)
  VALUES('S0002', 'K0001', 50, true);
INSERT INTO DETAILSTATIONS(station_id,bike_id,quantity,is_active)
  VALUES('S0003', 'K0003', 30, true);
INSERT INTO DETAILSTATIONS(station_id,bike_id,quantity,is_active)
  VALUES('S0004', 'K0002', 20, true);
INSERT INTO DETAILSTATIONS(station_id,bike_id,quantity,is_active)
  VALUES('S0005', 'K0004', 5, true);

-- SET IDENTITY_INSERT Booking OFF;