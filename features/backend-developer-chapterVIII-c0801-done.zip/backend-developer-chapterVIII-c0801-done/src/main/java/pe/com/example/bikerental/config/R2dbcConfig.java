package pe.com.example.bikerental.config;

import io.r2dbc.h2.H2ConnectionConfiguration;
import io.r2dbc.h2.H2ConnectionFactory;
import io.r2dbc.spi.ConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.r2dbc.config.AbstractR2dbcConfiguration;
import org.springframework.data.r2dbc.connectionfactory.init.CompositeDatabasePopulator;
import org.springframework.data.r2dbc.connectionfactory.init.ConnectionFactoryInitializer;
import org.springframework.data.r2dbc.connectionfactory.init.ResourceDatabasePopulator;
import org.springframework.data.r2dbc.core.DatabaseClient;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;

/**
 * Class: R2dbcConfig.
 *
 * Clase donde se configura la conexión a la base de datos y la carga inicial que esta tendrá.
 *
 */
@Configuration
@EnableR2dbcRepositories(basePackages = "pe.com.example.bikerental.thirdparty")
public class R2dbcConfig extends AbstractR2dbcConfiguration {


  @Autowired
  private H2Properties properties;

  /**
   * método que permite la configuración de la conexíon a la base de datos en general.
   * Para la actual configuración, se realiza la sobre driver H2, Al cual pasa por argemento la clase H2Propeties,
   * donde se espefica los definiciones con las que nos conectares a la base datos.
   *
   * @param properties
   * @return ConnectionFactory
   */
  @Bean
  @Override
  public ConnectionFactory connectionFactory() {
    // H2ConnectionConfiguration config = H2ConnectionConfiguration
    //     .builder()
    //     .inMemory(properties.getName())
    //     .url(properties.getUrl())
    //     .password(properties.getPassword())
    //     .username(properties.getUsername())
    //     .build();
    return H2ConnectionFactory.inMemory(properties.getName());
  }

  /**
   * método que abstrae la inicialización del schema y una carga inicial de datos.
   *
   * @param factory conexión hacia la base de datos
   * @param properties definición para la base de datos
   * @return ConnectionFactoryInitializer
   */
  @Bean
  public ConnectionFactoryInitializer initializerConfig(ConnectionFactory factory, H2Properties properties) {
    ConnectionFactoryInitializer initializer = new ConnectionFactoryInitializer();
    initializer.setConnectionFactory(factory);

    CompositeDatabasePopulator populator = new CompositeDatabasePopulator();
    populator.addPopulators(new ResourceDatabasePopulator(new ClassPathResource(properties.getSchema())));
    populator.addPopulators(new ResourceDatabasePopulator(new ClassPathResource(properties.getData())));
    initializer.setDatabasePopulator(populator);
    return initializer;
  }


  /**
   * método con el que exponemos en template de spring data para hacer un personalización en las transacciones que se vaya a utilizar.
   * @param factory
   * @return R2dbcEntityTemplate
   */
  @Bean
  public R2dbcEntityTemplate enableEntityTemplate(ConnectionFactory factory) {
    return new R2dbcEntityTemplate(DatabaseClient.create(factory));
  }

}
