package pe.com.example.bikerental.business.fn06;

import pe.com.example.bikerental.thirdparty.BikeRentalDto;
import reactor.core.publisher.Flux;

public interface UserRentService {

  Flux<BikeRentalDto> getUserRentsActivesRents(String userId);

}