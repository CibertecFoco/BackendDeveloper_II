package pe.com.example.bikerental.business.fn06;

import org.springframework.stereotype.Service;
import pe.com.example.bikerental.thirdparty.BikeRentalDto;
import reactor.core.publisher.Flux;

@Service
public class UserRentServiceImpl implements UserRentService {


  private final UserRentActiveSender sender;

  public UserRentServiceImpl(UserRentActiveSender sender) {
    this.sender = sender;
  }

  @Override
  public Flux<BikeRentalDto> getUserRentsActivesRents(String userId) {
    return sender.getUserRentsActivesRents(userId);
  }

}