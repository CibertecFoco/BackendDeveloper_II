package pe.com.example.bikerental.thirdparty;

import java.io.Serializable;
// import javax.persistence.Entity;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table(value = "Booking")
public class BikeRentalDto implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = -8824696542968163736L;

  @Id
  @Column(value = "booking_id")
  private Integer bookingId;

  @Column(value = "is_canceled")
  private boolean canceled;

  @Column(value = "created_at")
  private String created_at;

  @Column(value = "user_id")
  private String userId;

  @Column(value = "bike_id")
  private String bikeId;

  @Column(value = "is_completed")
  private boolean completed;

  @Column(value = "date_completed")
  private String completedDate;

  public Integer getBookingId() {
    return this.bookingId;
  }

  public void setBookingId(Integer bookingId) {
    this.bookingId = bookingId;
  }

  public boolean isCanceled() {
    return this.canceled;
  }

  public boolean getCanceled() {
    return this.canceled;
  }

  public void setCanceled(boolean canceled) {
    this.canceled = canceled;
  }

  public String getCreated_at() {
    return this.created_at;
  }

  public void setCreated_at(String created_at) {
    this.created_at = created_at;
  }

  public String getUserId() {
    return this.userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getBikeId() {
    return this.bikeId;
  }

  public void setBikeId(String bikeId) {
    this.bikeId = bikeId;
  }

  public boolean isCompleted() {
    return this.completed;
  }

  public boolean getCompleted() {
    return this.completed;
  }

  public void setCompleted(boolean completed) {
    this.completed = completed;
  }

  public String getCompletedDate() {
    return this.completedDate;
  }

  public void setCompletedDate(String completedDate) {
    this.completedDate = completedDate;
  }


}
