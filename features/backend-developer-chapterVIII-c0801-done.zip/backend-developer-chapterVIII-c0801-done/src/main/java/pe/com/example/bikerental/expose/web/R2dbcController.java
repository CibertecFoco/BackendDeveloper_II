package pe.com.example.bikerental.expose.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import pe.com.example.bikerental.business.fn03.BikeRentService;
import pe.com.example.bikerental.business.fn06.UserRentService;
import pe.com.example.bikerental.models.fn03.BikeRentRequest;
import pe.com.example.bikerental.models.fn03.BikeRentResponse;
import pe.com.example.bikerental.thirdparty.BikeRentalDto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Clase: R2dbcController.
 *
 * Clase ue expone los endpoints para poder interactuar con la aplicación.
 */
@RestController
@RequestMapping("/bike-rental/flux/v1")
public class R2dbcController {

  private final BikeRentService createService;
  private final UserRentService userRentService;

  public R2dbcController(BikeRentService creatService, UserRentService userRentService) {
    this.createService = creatService;
    this.userRentService = userRentService;
  }

  /**
   * método que expone en endpoint para poder crear una renta de bicicleta.
   *
   * @param payload body request
   * @return Mono
   */
  @PostMapping(value = "/rental", produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.CREATED)
  public Mono<BikeRentResponse> createBikeRents(@RequestBody BikeRentRequest payload) {
    return createService.createBikeRental(payload);
  }

  @GetMapping(value = "/user-rents/{userId}/active-rents", produces = {MediaType.APPLICATION_STREAM_JSON_VALUE})
  @ResponseStatus(HttpStatus.OK)
  public Flux<BikeRentalDto> getUserRentsActiveRentsByUserId(@PathVariable("userId") String userId) {
    return userRentService.getUserRentsActivesRents(userId);
  }

}
