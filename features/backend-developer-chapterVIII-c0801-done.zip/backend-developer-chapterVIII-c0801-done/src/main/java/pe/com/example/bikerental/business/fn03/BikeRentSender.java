package pe.com.example.bikerental.business.fn03;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.function.Function;
import org.springframework.stereotype.Component;
import pe.com.example.bikerental.models.fn03.BikeRentRequest;
import pe.com.example.bikerental.models.fn03.BikeRentResponse;
import pe.com.example.bikerental.repository.BikeRentRepository;
import pe.com.example.bikerental.thirdparty.BikeRentalDto;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@Component
public class BikeRentSender {

  private final BikeRentRepository repository;

  public BikeRentSender(BikeRentRepository repository) {
    this.repository = repository;
  }

  /**
   * método publico que permite de entrypoint para poder procesar y almacenar el nuevo alquiler de
   * bicicletas.
   *
   * @param payload Objecto del payload Request
   * @return Mono
   */
  public Mono<BikeRentResponse> saveBikeRental(BikeRentRequest payload) {
    return processPayloadToDto().apply(payload);
  }

  /**
   * método que realiza el proceso de transformación del payload request a la entidad que requiere ser
   * almacenada.
   *
   * @return Function
   */
  private Function<BikeRentRequest, Mono<BikeRentResponse>> processPayloadToDto() {
    return (payload) -> {
      BikeRentalDto bikeRental = new BikeRentalDto();
      bikeRental.setBikeId(payload.getBike().getCode());
      bikeRental.setCanceled(false);
      bikeRental.setCompleted(false);
      bikeRental.setCreated_at(LocalDateTime.now(ZoneId.systemDefault()).toString());
      bikeRental.setUserId(payload.getUserId());

      return transactDataBase().apply(bikeRental);
    };
  }

  /**
   * método que permite realizar la transacción en la base de datos.
   */
  private Function<BikeRentalDto, Mono<BikeRentResponse>> transactDataBase() {
    return (entity) -> {
      return repository.save(entity)
        .map((saved) -> new BikeRentResponse(saved.getBookingId()))
          .publishOn(Schedulers.elastic());
    };
  }

}
