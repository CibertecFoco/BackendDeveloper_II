package pe.com.example.bikerental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class R2dbcApplication {

  public static void main(String[] args) {
    SpringApplication.run(R2dbcApplication.class, args);
  }

}
