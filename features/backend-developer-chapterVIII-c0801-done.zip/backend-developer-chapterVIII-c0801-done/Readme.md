Spring Data R2dbc - H2
=======================

Caso:
------
Para esté caso de laboratorio, se realizará la implementanción R2dbc in memory, acceso a datos de forma non-blocking.
El laboratorio contempla dos casos, el primero es el registro de un alquiler de bicicletas y el segundo es listar
todos los alquileres activos que tienes un usuario, la consulta se realiza mediante el userId.

**Dependencias**

- Requerido:

  - spring boot webflux
  - spring boot data jpa
  - spring-boot-starter-data-r2dbc
  - r2dbc-h2

- Opcional:

  - spring boot actuator
  - spring boot devtools

----------

Pasos:
------

- agregar las dependencias mencionandas como requeridas.
- realizar la configuración en el archivo *src/resources/application.yml*
- realizar el mapping de los atributos definidos en el *application.yml*
- realizar la configuración de JavaBean *src/main/java/pe/com/example/bikerental/config/R2dbcConfig.java*
- definir los models de *src/main/java/pe/com/example/bikerental/models/fn03* y de thirdparty *src/main/java/pe/com/example/bikerental/thirdparty*
- definir la interface *Repository* como se muestra en la ruta *src/main/java/pe/com/example/bikerental/repository*.
- ahora definiremos la lógica de negocio como se muestra en package **src.main.java.pe.com.example.bikerental.business**
  - la funcionaliad fn03, es para la creación de alquileres de bicicletas.
  - la funcionalidad fn06, es para la consulta de alquileres activos.
- finalmente realizamos la expocisión de los endpoints a través del controlador *src/main/java/pe/com/example/bikerental/expose/web/R2dbcController.java*

-------


Pruebas:
---------

Las pruebas se pueden realiazar desde el *collection postman*, en la ruta */src/main/resources/postman/*.

cURL:
------

```bash
curl --location --request GET 'http://localhost:8080/bike-rental/flux/v1/user-rents/U0001/active-rents'
```

Links:
--------------------

 - https://docs.spring.io/spring-data/r2dbc/docs/1.1.3.RELEASE/reference/html/#reference
 - https://www.baeldung.com/spring-data-r2dbc
 - https://github.com/spring-projects/spring-data-r2dbc
 - https://medium.com/@hantsy/reactive-accessing-rdbms-with-spring-data-r2dbc-d6e453f2837e