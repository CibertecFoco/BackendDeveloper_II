Project Reactor
==============
Opertator
---------

### Map

##### Caso:
Para este laboratorio se realiza la construcción de un objecto Card. Hacemos uso de operator Map() de Project-Reactor para poder modificar el contenido del objecto.
Inicialmente se pasa una nueva instancia del objecto Card, al cual se le añade valores a sus variables de instancia.

Finalmente la clase principal MapApplication, muestra la instancia de Card genarada en la clase servicio con todos los atributos que se le ha ido añadiendo con los map().
