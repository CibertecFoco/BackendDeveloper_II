package pe.com.example.reactor.business;

import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Card;
import reactor.core.publisher.Mono;

@Service
public class TransformOperatorService {

  // private static final Logger log = LoggerFactory.getLogger(TransformOperatorService.class);

  private AccountService accounts;
  private ClientService client;

  public TransformOperatorService(AccountService accounts, ClientService client) {
    this.accounts = accounts;
    this.client = client;
  }

  public Mono<Card> getCardDetail(String ClientId) {
    Card newCard = new Card();
    return Mono.just(newCard).log().map(card -> {
      card.setCardId("4545634523479823");
      return card;
    }).map(card -> {
      card.setCardFormatted("4545-6345-2347-9823");
      return card;
    }).map(card -> {
      card.setAccounts(accounts.getAllAccounts(ClientId));
      return card;
    }).map(card -> {
      card.setClient(client.getClientDetails(ClientId));
      return card;
    }).log();
  }

}
