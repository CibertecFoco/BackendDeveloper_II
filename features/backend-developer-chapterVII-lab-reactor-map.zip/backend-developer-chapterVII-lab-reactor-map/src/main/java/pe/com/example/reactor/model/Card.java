package pe.com.example.reactor.model;

import java.util.List;

public class Card {

  private String cardId;
  private String cardFormatted;
  private Client client;
  private List<Account> accounts;
  private boolean active;

  /**
   * @return the active
   */
  public boolean isActive() {
    return active;
  }

  /**
   * @return the cardId
   */
  public String getCardId() {
    return cardId;
  }

  /**
   * @param cardId the cardId to set
   */
  public void setCardId(String cardId) {
    this.cardId = cardId;
  }

  /**
   * @return the cardFormatted
   */
  public String getCardFormatted() {
    return cardFormatted;
  }

  /**
   * @param cardFormatted the cardFormatted to set
   */
  public void setCardFormatted(String cardFormatted) {
    this.cardFormatted = cardFormatted;
  }

  /**
   * @return the client
   */
  public Client getClient() {
    return client;
  }

  /**
   * @param client the client to set
   */
  public void setClient(Client client) {
    this.client = client;
  }

  /**
   * @return the accounts
   */
  public List<Account> getAccounts() {
    return accounts;
  }

  /**
   * @param accounts the accounts to set
   */
  public void setAccounts(List<Account> accounts) {
    this.accounts = accounts;
  }

  /**
   * @param active the active to set
   */
  public void setActive(boolean active) {
    this.active = active;
  }

}