package pe.com.example.reactor;

import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import pe.com.example.reactor.business.TransformOperatorService;

@SpringBootApplication
public class MapApplication implements CommandLineRunner {

  private static final Logger log = LoggerFactory.getLogger(MapApplication.class);

  @Autowired
  TransformOperatorService service;

  public static void main(String[] args) {
    SpringApplication.run(MapApplication.class, args);
  }

  @Override
  public void run(String... args) throws Exception {
    String clientId = "101010101";
    service.getCardDetail(clientId).subscribe((card) -> {
      log.info("[Get Card Details]");
      log.info("{} ", card.getCardId());
      log.info("{} ", card.getCardFormatted());
      log.info("{} ", card.getClient());
      log.info("{} ", Arrays.toString(card.getAccounts().toArray()));
      log.info("{} ", card.getAccounts().size());
      log.info("{} ", card);
    });

  }

}
