Project Reactor
===============

Opertator
---------

- FlapMap


Caso:
-----

Para este laboratorio se realiza el consumo de dos métodos los cuales nos retorna una lista de cuentas de ahorros y una lista de cuentas maestras respectivamente. 
Los métodos que retornan las cuentas son de tipo *Flux*, lo que se busca hacer es realizar una conversión de tipo de método reactivo haciendo uso de FlatMap podemos hacer el campo de método.
Finalmente la clase principal OperatorApplication, muestra la suscripción y muestra los datos de las cuentas número, tipo, y saldo disponible.
