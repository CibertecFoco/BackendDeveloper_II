package pe.com.example.reactor.business;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Account;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class TransformService {

  private AccountService accounts;

  public TransformService(AccountService accounts, ClientService client) {
    this.accounts = accounts;
  }

  public Mono<List<Account>> getTwoSourceAccounts(String ClientId) {
    return accounts.getMasterAccounts(ClientId)
      .mergeWith(accounts.getSavingsAccounts(ClientId))
        .flatMap(Mono::just)
        .collectList();
  }

}
