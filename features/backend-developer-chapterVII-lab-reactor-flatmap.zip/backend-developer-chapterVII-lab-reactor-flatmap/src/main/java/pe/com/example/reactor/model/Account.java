package pe.com.example.reactor.model;

import java.math.BigDecimal;

public class Account {

  private String accountId;
  private String name;
  private BigDecimal availableAmount;
  private BigDecimal accountingAmount;

  private String type;

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @return the type
   */
  public String getType() {
    return type;
  }

  /**
   * @param type the type to set
   */
  public void setType(String type) {
    this.type = type;
  }

  /**
   * @return the accountingAmount
   */
  public BigDecimal getAccountingAmount() {
    return accountingAmount;
  }

  /**
   * @param accountingAmount the accountingAmount to set
   */
  public void setAccountingAmount(BigDecimal accountingAmount) {
    this.accountingAmount = accountingAmount;
  }

  /**
   * @return the availableAmount
   */
  public BigDecimal getAvailableAmount() {
    return availableAmount;
  }

  /**
   * @param availableAmount the availableAmount to set
   */
  public void setAvailableAmount(BigDecimal availableAmount) {
    this.availableAmount = availableAmount;
  }

  /**
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * @return the productId
   */
  public String getAccountId() {
    return accountId;
  }

  /**
   * @param accountId the productId to set
   */
  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  @Override
  public String toString() {
    return String.format("[accountId=%s, name=%s, availableAmount=%f, accoutingAmount=%f]",
        this.getAccountId(), this.getName(), this.getAvailableAmount(), this.getAccountingAmount());
  }

}
