package pe.com.example.c0501.bikerental.constants;

public final class QueryStatement {

  public static final String QUERY_INSERT_BOOKING =
      "INSERT INTO [cibertec].[BOOKING](is_canceled, created_at, user_id, bike_id) VALUES(0, ?, ?, ?)";

  public static final String QUERY_INSERT_RENTAL_DETAILS =
      "INSERT INTO [cibertec].[RENTALDETAILS](booking_id, origin_station_id, destination_station_id, start_date, end_date) "
      + "VALUES((SELECT BOOKING_ID FROM [cibertec].[BOOKING] WHERE CREATED_AT = ? AND USER_ID = ? AND is_canceled = 0), ?, ?, ?, ?)";

}
