package pe.com.example.c0501.bikerental.business.fn03;

import java.sql.SQLException;
import pe.com.example.c0501.bikerental.models.api.fn03.request.BikeBookingRequest;

/**
 * method interface for create new Booking.
 */
public interface BookingService {

  /**
   * Este método proporciona el acceso a la implementación para la creación de la reserva de la bicicleta.
   * @param payload un objecto BikeBookingRequesy, contiene la información necesario para la creación de la renta.
   * @throws SQLException si ocurre alguna excepción con la base de datos.
   * @see BikeBookingRequest
   */
  void createBikeBooking(BikeBookingRequest payload) throws SQLException;

}