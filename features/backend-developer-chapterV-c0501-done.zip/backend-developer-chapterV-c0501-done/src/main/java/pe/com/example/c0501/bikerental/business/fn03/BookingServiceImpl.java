package pe.com.example.c0501.bikerental.business.fn03;

import java.sql.SQLException;
import org.springframework.stereotype.Service;
import pe.com.example.c0501.bikerental.models.api.fn03.request.BikeBookingRequest;

@Service
public class BookingServiceImpl implements BookingService {

  private final BookingRepository repository;

  public BookingServiceImpl(BookingRepository repository) {
    this.repository = repository;
  }

  @Override
  public void createBikeBooking(BikeBookingRequest payload) throws SQLException {
    repository.createBookingAndDetails(payload);

  }



}