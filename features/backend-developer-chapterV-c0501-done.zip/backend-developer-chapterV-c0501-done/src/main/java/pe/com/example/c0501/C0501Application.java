package pe.com.example.c0501;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

/**
 * excluir la auticonfiguración, ya que se esta haciendo la configuracion del Datasource a traves de un javaconfig.
 *
 * @param args
 */
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class C0501Application {

  public static void main(String[] args) {
    SpringApplication.run(C0501Application.class, args);
  }

}
