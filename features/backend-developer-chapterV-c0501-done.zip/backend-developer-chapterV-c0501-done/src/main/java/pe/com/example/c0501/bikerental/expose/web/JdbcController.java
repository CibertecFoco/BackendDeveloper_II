package pe.com.example.c0501.bikerental.expose.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import pe.com.example.c0501.bikerental.business.fn03.BookingService;
import pe.com.example.c0501.bikerental.models.api.fn03.request.BikeBookingRequest;

@RestController
@RequestMapping("/bike-rental/mvc/v1")
public class JdbcController {

  private final BookingService bookingService;

  public JdbcController(BookingService bookingService) {
    this.bookingService = bookingService;
  }

  /**
   * El método expone la funcionalidad de creación de una reserva de bicicleta, que espera único parametro de entreda a {@link BikeBookingRequest}.
   * la funcionalidad hace uso de JdbcTemplate para poder transaccionar con la base de datos (Azure SQL).
   * @param payload BikeBoolingRequesy
   * @throws Exception general de producirse alguna excepción con el flujo o db.
   */
  @PostMapping(value = "/rents", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.CREATED)
  public void createBooking(@RequestBody BikeBookingRequest payload) throws Exception {
    bookingService.createBikeBooking(payload);
  }

}
