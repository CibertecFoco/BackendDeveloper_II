package pe.com.example.c0501.bikerental.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class JdbcConfig {

  private static final Logger log = LoggerFactory.getLogger(JdbcConfig.class);

  /**
   * definición del Bean para configurar el datasource.
   * @param properties extraidas desde archivo application.yml
   * @return DataSource
   */
  @Bean
  public DataSource getDataSource(DataSourceProperties properties) {
    log.info("[config datasource] to azure");
    HikariConfig config = new HikariConfig();
    config.setDriverClassName(properties.getDriverClassName());
    config.setJdbcUrl(properties.getUrl());
    config.setUsername(properties.getUsername());
    config.setPassword(properties.getPassword());
    log.info("{}", properties.getUrl());
    return new HikariDataSource(config);
  }

 /**
 * Se configura el JdbcTemplate con el datasoruce generado en el método getDataSource.
 * @param properties from resources/application.yml
 * @return JdbcTempalte
 */
  @Bean
  public JdbcTemplate getJdbcTemplate(DataSourceProperties properties) {
    return new JdbcTemplate(getDataSource(properties));
  }

}