package pe.com.example.c0501.bikerental.business.fn03;

import static pe.com.example.c0501.bikerental.constants.QueryStatement.QUERY_INSERT_BOOKING;
import static pe.com.example.c0501.bikerental.constants.QueryStatement.QUERY_INSERT_RENTAL_DETAILS;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import pe.com.example.c0501.bikerental.models.api.fn03.request.BikeBookingRequest;

/**
 * class: donde se gestiona las transacciones con la base de datos.
 *
 */
@Component
public class BookingRepository {

  private static final Logger log = LoggerFactory.getLogger(BookingRepository.class);
  private final JdbcTemplate template;

  public BookingRepository(JdbcTemplate template) {
    this.template = template;
  }

  /**
   * método con el que se transaccion con la base de datos, se hace uso del método update de JdbTemplate para hacer efectivo el insert.
   * se utliza dos versiones del update, la primera donde se le indica el tipo de dato de cada variable y la segunda solo donde se establece los
   * @param payload request
   * @throws SQLException exception
   */
  public void createBookingAndDetails(BikeBookingRequest payload) throws DataAccessException {
    String createAt = LocalDateTime.now(ZoneId.of("America/Lima")).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'hh:mm:ss"));
    log.info("[insert start]");
    int rowAffected = template.update(QUERY_INSERT_BOOKING,
        new Object[] {createAt, payload.getUserId(), payload.getBike().getCode()},
        new int[] {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR});
    if (rowAffected >= 1) {
      template.update(QUERY_INSERT_RENTAL_DETAILS,
          new Object[] {createAt, payload.getUserId(), payload.getOrigin().getStation().getCode(),
              payload.getDestination().getStation().getCode(), payload.getStartDate(), null});
    }
    log.info("[insert finish]");
  }

}
