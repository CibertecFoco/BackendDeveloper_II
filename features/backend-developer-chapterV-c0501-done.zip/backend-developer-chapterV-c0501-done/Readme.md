Spring JDBC
===========

Para este laboratorio se requiere realizar la implementación de la funcionalidad de creción de una reserva de bicicletas.

Para la cual se hará uso de del siguiente stack:

##### Requeridos
- spring boot web
- Spring Jdbc
- mssql-jdbc:8.2.2 (depende jdk)

#### Opcionales
- spring boot actutor
- spring boot validator (used javax.validation)


Para la implementación se debe tomar en consideración que el modelo de la base de datos ya debe existir, ya que no se esta embebiendo o haciendo uso de un ORM para la gestion para DDL.
En la ruta *src/main/resources/scripts/schema-data.sql* se encuentra el modelo de la base de datos a utilizar.

> Las credenciales establecidad para el acceso a la base de datos solo están disponibles hasta el 2020-08-15, 
> despúes de dicha fecha se tendrá que habilitar un nuevo componente en AzureSQL para demostrar el laboratorio o en su defecto hacerlo con un base de datos en local.

----

- Agregar las dependencias anteriormente mencionadas.
- habilitar el javaConfig para hacer uso del datasoruce y de JdbcTemplate (revisa el package pe.com.example.c0501.bikerental.config).
- realizar la implementación de los modelos ( revisar el package pe.com.example.c0501.bikerental.models.api.fn03.request)
- Implementar la clase que hará las transaciones revisar la clase BookinRepository.java ubicado en package pe.com.example.c0501.bikerental.business.fn03
- Implementar las clases necesarias para exponer la funcionalidad de creación de una reserva de bicicleta. (JdbcController.java)
