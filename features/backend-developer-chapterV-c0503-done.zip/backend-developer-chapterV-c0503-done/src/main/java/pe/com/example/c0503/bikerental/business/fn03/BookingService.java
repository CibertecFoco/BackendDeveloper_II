package pe.com.example.c0503.bikerental.business.fn03;

import java.sql.SQLException;
import java.util.List;
import pe.com.example.c0503.bikerental.models.api.fn03.request.RentalBikeRequest;
import pe.com.example.c0503.bikerental.thirdparty.redis.BookingHistoryDto;

/**
 * method interface for create new Booking.
 */
public interface BookingService {

  void createNewBooking(RentalBikeRequest payload) throws SQLException;

  void completingBookingById(int bookingId) throws SQLException;

  void cancellingBookingById(int bookingId) throws SQLException;

  List<BookingHistoryDto> getHistoryByUserId(String userId);

}