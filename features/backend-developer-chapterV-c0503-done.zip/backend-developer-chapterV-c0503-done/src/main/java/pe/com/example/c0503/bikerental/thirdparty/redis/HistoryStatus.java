package pe.com.example.c0503.bikerental.thirdparty.redis;

public enum HistoryStatus {

  REGISTER,
  CANCELLING,
  COMPLETED;

}