package pe.com.example.c0503.bikerental.repository.mssql;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.com.example.c0503.bikerental.thirdparty.mssql.BookingDto;

@Repository
public interface BookingRepository extends JpaRepository<BookingDto, Integer> {

}