package pe.com.example.c0503.bikerental.business.fn03;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import pe.com.example.c0503.bikerental.models.api.fn03.request.RentalBikeRequest;
import pe.com.example.c0503.bikerental.repository.mssql.BookingRepository;
import pe.com.example.c0503.bikerental.repository.redis.BookingHistoryRepository;
import pe.com.example.c0503.bikerental.thirdparty.mssql.BookingDto;
import pe.com.example.c0503.bikerental.thirdparty.redis.BookingHistoryDto;
import pe.com.example.c0503.bikerental.thirdparty.redis.HistoryStatus;

@Component
public class BookingSender {

  private static final Logger log = LoggerFactory.getLogger(BookingSender.class);

  private BookingRepository bookingRepository;
  private BookingHistoryRepository historyRepository;

  public BookingSender(BookingRepository repository, BookingHistoryRepository historyRepo) {
    this.bookingRepository = repository;
    this.historyRepository = historyRepo;
  }

  /**
   * method for create a new booking.
   *
   * @param payload request
   * @throws SQLException exception
   */
  public void createBookingAndDetails(RentalBikeRequest payload) throws DataAccessException {
    LocalDateTime createAt = LocalDateTime.now(ZoneId.of("America/Lima")); // .format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'hh:mm:ss"));
    BookingDto dto = new BookingDto();

    // block storage data in azure sql
    dto.setCreatedAt(createAt);
    dto.setUserId(payload.getUserId());
    dto.setBikeId(payload.getBike().getCode());
    // spring data repository
    BookingDto booking = bookingRepository.save(dto);

    // block storega data in redis history
    interactionHistory(booking.getBookingId(), booking.getUserId(), HistoryStatus.REGISTER, createAt);
  }

  public void completeBooking(int bookingId) throws SQLException {

    Optional<BookingDto> booking = bookingRepository.findById(Integer.valueOf(bookingId));
    if (booking.isPresent() && !booking.get().isCanceled()) {
      LocalDateTime timeCompleted = LocalDateTime.now(ZoneId.of("America/Lima"));
      BookingDto dto = booking.get();
      dto.setCompleted(true);
      dto.setDateCompleted(timeCompleted);
      bookingRepository.save(dto);

      interactionHistory(dto.getBookingId(), dto.getUserId(), HistoryStatus.COMPLETED, timeCompleted);
      log.info("[save cache]");
    } else {
      throw new SQLException("BookingId not found or Booking Canceled");
    }
  }

  public void cancellingBooking(int bookingId) throws SQLException {

    Optional<BookingDto> booking = bookingRepository.findById(Integer.valueOf(bookingId));
    if (booking.isPresent() && !booking.get().isCompleted()) {

      LocalDateTime timeCancelling = LocalDateTime.now(ZoneId.of("America/Lima"));
      BookingDto dto = booking.get();
      dto.setCanceled(true);
      dto.setDateCompleted(timeCancelling);
      bookingRepository.save(dto);

      interactionHistory(dto.getBookingId(), dto.getUserId(), HistoryStatus.CANCELLING,
          timeCancelling);
      log.info("[save cache]");

    } else {
      throw new SQLException("BookingId not found");
    }
  }

  public List<BookingHistoryDto> getHistoryByUserId(String userId) {
    List<BookingHistoryDto> lst = historyRepository.findByUserId(userId);
    return lst;
  }

  private void interactionHistory(int bookingId, String userId, HistoryStatus status, LocalDateTime datetime) {
    BookingHistoryDto history = new BookingHistoryDto();
    history.setBookingId(bookingId);
    history.setUserId(userId);
    history.setStatus(status);
    history.setRegisterDate(datetime.toString());
    historyRepository.save(history);

  }

}
