package pe.com.example.c0503.bikerental.repository.redis;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import pe.com.example.c0503.bikerental.thirdparty.redis.BookingHistoryDto;

public interface BookingHistoryRepository extends CrudRepository<BookingHistoryDto, String> {

  List<BookingHistoryDto> findByUserId(String userId);

}