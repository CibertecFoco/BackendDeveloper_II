package pe.com.example.c0503.bikerental.expose.web;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import pe.com.example.c0503.bikerental.business.fn03.BookingService;
import pe.com.example.c0503.bikerental.models.api.fn03.request.RentalBikeRequest;
import pe.com.example.c0503.bikerental.thirdparty.redis.BookingHistoryDto;

@RestController
@RequestMapping("/bike-rental/mvc/v1")
public class CacheController {

  private static final Logger log = LoggerFactory.getLogger(CacheController.class);

  private final BookingService bookingService;

  public CacheController(BookingService bookingService) {
    this.bookingService = bookingService;
  }

  @PostMapping(value = "/rents", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.CREATED)
  public void createBooking(@RequestBody RentalBikeRequest payload) throws Exception {
    bookingService.createNewBooking(payload);
  }

  @PatchMapping(value = "/rents/{bookingId}", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void completingBikeBooking(@PathVariable("bookingId") int bookingId) throws Exception {
    log.info("[starting completing booking]");
    bookingService.completingBookingById(bookingId);
  }

  @DeleteMapping(value = "/rents/{bookingId}", consumes = {MediaType.APPLICATION_JSON_VALUE},
      produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void cancellingBikeBooking(@PathVariable("bookingId") int bookingId) throws Exception {
    log.info("[starting cancelling booking]");
    bookingService.cancellingBookingById(bookingId);
  }

  @GetMapping(value = "/histories/{userId}", produces = {MediaType.APPLICATION_JSON_VALUE})
  @ResponseStatus(HttpStatus.OK)
  public List<BookingHistoryDto> getHistoryInteractionByUserId(
      @PathVariable("userId") String userId) {
    return bookingService.getHistoryByUserId(userId);
  }

}