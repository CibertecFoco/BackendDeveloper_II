package pe.com.example.c0503.bikerental.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import pe.com.example.c0503.bikerental.repository.mssql.BookingRepository;
import pe.com.example.c0503.bikerental.repository.redis.BookingHistoryRepository;


/*
 * Clase que se encarga de realizar las configuraciones para exponer objectos necsarios para
 * conectarse a Redis Class: RedisConfig
 */
@Configuration
@EnableRedisRepositories(basePackageClasses = {BookingHistoryRepository.class})
@EnableJpaRepositories(basePackageClasses = {BookingRepository.class})
public class RedisConfig {

  @Value("${application.redis.host:localhost}")
  private String host;
  @Value("${application.redis.password:qwerty}")
  private String password;
  @Value("${application.redis.port:6379}")
  private int port;

  public String getHost() {
    return this.host;
  }

  public void setHost(String host) {
    this.host = host;
  }

  public String getPassword() {
    return this.password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public int getPort() {
    return this.port;
  }

  public void setPort(int port) {
    this.port = port;
  }

  /**
   * método que crea un bean para la conexión a Redis. Este médoto implementa una instancia de
   * RedisStandaloneConfiguration ya no para el laboratorio no se cuenta con un cluster.
   *
   * Data Redis tiene la posibilidad de poder interactuar con un par de clientes Redis - Jedis y
   * Lettuce. Para el este caso utilizaremos Jedis como driver client para llegar a Redis
   * https://docs.spring.io/spring-data/redis/docs/2.3.2.RELEASE/reference/html/#redis:connectors:connection
   *
   * @return RedisConnectionFactory
   */
  @Bean
  public RedisConnectionFactory redisConnectionFactory() {
    RedisStandaloneConfiguration standaloneAzure = new RedisStandaloneConfiguration();
    standaloneAzure.setHostName(getHost());
    standaloneAzure.setPassword(getPassword());
    standaloneAzure.setPort(getPort());
    return new JedisConnectionFactory(standaloneAzure); // Jedis don't support Non-Blocking requests
    // return new LettuceConnectionFactory(standaloneAzure); // Lettuce sopports Non-Blocking requests
  }

}
