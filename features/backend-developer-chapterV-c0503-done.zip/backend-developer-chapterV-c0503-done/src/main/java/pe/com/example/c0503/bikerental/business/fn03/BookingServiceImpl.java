package pe.com.example.c0503.bikerental.business.fn03;

import java.sql.SQLException;
import java.util.List;
import org.springframework.stereotype.Service;
import pe.com.example.c0503.bikerental.models.api.fn03.request.RentalBikeRequest;
import pe.com.example.c0503.bikerental.thirdparty.redis.BookingHistoryDto;

@Service
public class BookingServiceImpl implements BookingService {

  private final BookingSender sender;

  public BookingServiceImpl(BookingSender sender) {
    this.sender = sender;
  }

  @Override
  public void createNewBooking(RentalBikeRequest payload) throws SQLException {
    sender.createBookingAndDetails(payload);

  }

  @Override
  public void completingBookingById(int bookingId) throws SQLException {
    sender.completeBooking(bookingId);
  }

  @Override
  public void cancellingBookingById(int bookingId) throws SQLException {
    sender.cancellingBooking(bookingId);
  }

  @Override
  public List<BookingHistoryDto> getHistoryByUserId(String userId) {
    return sender.getHistoryByUserId(userId);
  }



}