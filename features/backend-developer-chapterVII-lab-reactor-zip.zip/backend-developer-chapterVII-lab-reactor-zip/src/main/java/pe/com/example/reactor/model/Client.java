package pe.com.example.reactor.model;

import java.util.List;

public class Client {

  private String clientId;
  private String name;
  private String gender;
  private String segment;
  private boolean active;
  private List<Product> products;

  /**
   * @return the clientId
   */
  public String getClientId() {
    return clientId;
  }

  /**
   * @return the products
   */
  public List<Product> getProducts() {
    return products;
  }

  /**
   * @param products the products to set
   */
  public void setProducts(List<Product> products) {
    this.products = products;
  }

  /**
   * @return the active
   */
  public boolean isActive() {
    return active;
  }

  /**
   * @param active the active to set
   */
  public void setActive(boolean active) {
    this.active = active;
  }

  /**
   * @return the segment
   */
  public String getSegment() {
    return segment;
  }

  /**
   * @param segment the segment to set
   */
  public void setSegment(String segment) {
    this.segment = segment;
  }

  /**
   * @return the gender
   */
  public String getGender() {
    return gender;
  }

  /**
   * @param gender the gender to set
   */
  public void setGender(String gender) {
    this.gender = gender;
  }

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * @param clientId the clientId to set
   */
  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  @Override
  public String toString() {
    return String.format("[clientId=%s, name=%s, gender=%s, segment=%s, active=%b, products=%s]",
        this.getClientId(), this.getName(), this.getGender(), this.getSegment(), this.isActive(), this.getProducts());
  }

}
