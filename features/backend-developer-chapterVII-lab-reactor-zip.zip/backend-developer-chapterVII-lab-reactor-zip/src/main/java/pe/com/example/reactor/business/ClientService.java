package pe.com.example.reactor.business;

import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Client;
import reactor.core.publisher.Mono;

@Service
public class ClientService {

  public Client getClientDetails(String clientId) {
    return findById(clientId);
  }

  public Mono<Client> getClient(String clientId) {
    return Mono.just(getClientDetails(clientId));
  }

  private Client findById(String clientId) {
    Client client = new Client();
    client.setClientId(clientId);
    client.setName("Alessando Rodriguez Cruz");
    client.setGender("M");
    client.setSegment("M1N");
    client.setActive(true);
    return client;
  }
}