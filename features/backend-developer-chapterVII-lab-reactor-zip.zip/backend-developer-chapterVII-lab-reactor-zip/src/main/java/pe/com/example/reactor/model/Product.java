package pe.com.example.reactor.model;

public class Product {

  private String referenceId;

  /**
   * @return the referenceId
   */
  public String getReferenceId() {
    return referenceId;
  }

  /**
   * @param referenceId the referenceId to set
   */
  public void setReferenceId(String referenceId) {
    this.referenceId = referenceId;
  }

}