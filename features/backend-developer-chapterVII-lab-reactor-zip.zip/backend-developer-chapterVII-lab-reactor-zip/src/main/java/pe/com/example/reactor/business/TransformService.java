package pe.com.example.reactor.business;

import java.util.LinkedList;
import java.util.List;
import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Client;
import pe.com.example.reactor.model.Product;
import reactor.core.publisher.Mono;

@Service
public class TransformService {

  private AccountService accounts;
  private CardService cards;
  private ClientService client;

  public TransformService(AccountService accounts, CardService cards, ClientService client) {
    this.accounts = accounts;
    this.cards = cards;
    this.client = client;
  }

  public Mono<Client> getDetailsClient(String clientId) {
    return Mono.zip(accounts.getAllAccounts(clientId).collectList(), cards.getAllCards(clientId).collectList())
    .flatMap(data -> {
      List<Product> lst = new LinkedList<>();
      data.getT1().forEach(lst::add);
      data.getT2().forEach(lst::add);
      return Mono.just(lst);
    })
    .zipWith(client.getClient(clientId))
    .flatMap(data -> {
      Client customer = data.getT2();
      customer.setProducts(data.getT1());
      return Mono.just(customer);
        });
  }

}
