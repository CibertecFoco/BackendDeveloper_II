package pe.com.example.reactor.model;

import java.math.BigDecimal;

public class Account extends Product {

  private String accountFormattedId;
  private String name;
  private BigDecimal availableAmount;
  private BigDecimal accountingAmount;

  /**
   * @return the name
   */
  public String getName() {
    return name;
  }

  /**
   * @return the accountFormattedId
   */
  public String getAccountFormattedId() {
    return accountFormattedId;
  }

  /**
   * @param accountFormattedId the accountFormattedId to set
   */
  public void setAccountFormattedId(String accountFormattedId) {
    this.accountFormattedId = accountFormattedId;
  }

  /**
   * @return the accountingAmount
   */
  public BigDecimal getAccountingAmount() {
    return accountingAmount;
  }

  /**
   * @param accountingAmount the accountingAmount to set
   */
  public void setAccountingAmount(BigDecimal accountingAmount) {
    this.accountingAmount = accountingAmount;
  }

  /**
   * @return the availableAmount
   */
  public BigDecimal getAvailableAmount() {
    return availableAmount;
  }

  /**
   * @param availableAmount the availableAmount to set
   */
  public void setAvailableAmount(BigDecimal availableAmount) {
    this.availableAmount = availableAmount;
  }

  /**
   * @param name the name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    return String.format("[referenceId=%s, accountId=%s, name=%s, availableAmount=%f, accoutingAmount=%f]",
        this.getReferenceId(), this.getAccountFormattedId(), this.getName(), this.getAvailableAmount(), this.getAccountingAmount());
  }

}
