package pe.com.example.reactor.business;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import pe.com.example.reactor.model.Card;
import reactor.core.publisher.Flux;

@Service
public class CardService {

  private AccountService account;

  private static final Logger log = LoggerFactory.getLogger(CardService.class);

  public CardService(AccountService account) {
    this.account = account;
  }

  public Flux<Card> getAllCards(String clientId) {
    log.info("----------------------------------------------");
    return Flux.<Card>fromIterable(getCards(clientId));
  }

  public List<Card> getCards(String clientId) {
    List<Card> cards = new LinkedList<>();
    int ncard = new Random().nextInt(8);
    log.info("[card] generate cards {} length", ncard);
     while ((ncard--) > 0) {
       cards.add(generateCard(clientId));
       log.info("add card");
     }
    return cards;
  }

  public Card generateCard(String clientId) {
    Card card = new Card();
    int cardid = new Random().nextInt(1000);
    card.setReferenceId(String.format("453200324323%d", Math.abs(cardid)));
    card.setCardFormatted(String.format("4532-0032-4323-%d", Math.abs(cardid)));
    card.setActive(new Random().nextBoolean());
    card.setAccounts(account.getAccounts(clientId));
    return card;
  }

}