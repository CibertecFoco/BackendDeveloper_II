Project Reactor
===============

Opertator
---------

- Zip

#### Caso:

Para este laboratorio se realiza la construcción de un objecto Client. Mediante el uno del operador .zip() se une las listas de cuentas y tarjetas, una vez obtenida ambas listas,
se procede a realizar una conversión para retornar el una lista de productos, después de a través del operador .zipWith() añada los datos el cliente.

Finalmente la clase principal OperatorsApplication, muestra la suscripción y muestra los datos del cliente con su lista de productos.

