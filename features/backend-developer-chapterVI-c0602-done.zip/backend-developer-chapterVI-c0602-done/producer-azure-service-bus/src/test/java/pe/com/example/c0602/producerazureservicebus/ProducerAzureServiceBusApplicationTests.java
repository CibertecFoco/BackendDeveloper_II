package pe.com.example.c0602.producerazureservicebus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerAzureServiceBusApplicationTests {

	@Test
	void contextLoads() {
	}

}
