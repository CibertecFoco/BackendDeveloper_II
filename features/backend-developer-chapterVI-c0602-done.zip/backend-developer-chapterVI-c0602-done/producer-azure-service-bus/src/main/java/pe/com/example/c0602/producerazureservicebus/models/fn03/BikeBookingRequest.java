package pe.com.example.c0602.producerazureservicebus.models.fn03;

import java.io.Serializable;

public class BikeBookingRequest implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 1475012335068290253L;

  private String startDate;

  private BookingStationVo origin;

  private BookingStationVo destination;

  private BikeVo bike;

  private String userId;

  public String getStartDate() {
    return this.startDate;
  }

  public void setStartDate(String startDate) {
    this.startDate = startDate;
  }

  public BookingStationVo getOrigin() {
    return this.origin;
  }

  public void setOrigin(BookingStationVo origin) {
    this.origin = origin;
  }

  public BookingStationVo getDestination() {
    return this.destination;
  }

  public void setDestination(BookingStationVo destination) {
    this.destination = destination;
  }

  public BikeVo getBike() {
    return this.bike;
  }

  public void setBike(BikeVo bike) {
    this.bike = bike;
  }

  public String getUserId() {
    return this.userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

}