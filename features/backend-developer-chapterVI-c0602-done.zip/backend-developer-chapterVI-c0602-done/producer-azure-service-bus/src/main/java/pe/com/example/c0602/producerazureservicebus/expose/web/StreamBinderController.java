package pe.com.example.c0602.producerazureservicebus.expose.web;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import pe.com.example.c0602.producerazureservicebus.bindings.StreamBinderProducer;
import pe.com.example.c0602.producerazureservicebus.models.fn03.BikeBookingRequest;

/**
 * Esta clase es la entrada principal para la recepción de las solicitudes a través del endpoint
 * expuesto.
 */
@RestController
@RequestMapping("/bike-rental/mvc/v1")
public class StreamBinderController {

  private static final Logger log = LoggerFactory.getLogger(StreamBinderController.class);

  private StreamBinderProducer producer;

  public StreamBinderController(StreamBinderProducer producer) {
    this.producer = producer;
  }

  /**
   * método que permite la recepción del payload para ser enviado al service bus para su ejecución
   * sobre otra aplicación.
   *
   * @param payload
   * @return Map<String, String>
   */
  @PostMapping(value = "/booking", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.ACCEPTED)
  public Map<String, String> postMessage(@RequestBody BikeBookingRequest payload) {
    log.info("[booking] starting send payload");
    return producer.sendMessageToServiceBusCreatingTopic(payload);
  }

  /**
   * método que permite el envío del identificador del alquiler para poder realizar la cancelación del
   * alquiler.
   *
   * @param bookingId
   * @return Map<String, String>
   */
  @DeleteMapping(value = "booking/{bookingId}", produces = MediaType.APPLICATION_JSON_VALUE)
  @ResponseStatus(HttpStatus.OK)
  public Map<String, String> cancellingBookingByBookingId(@PathVariable("bookingId") int bookingId) {
    log.info("[cancelling] start process cancelling for bookingId {}", bookingId);
    return producer.sendMessageToServiceBusCancellingTopic(bookingId);
  }

}
