package pe.com.example.c0602.producerazureservicebus.messaging;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

public interface CancellingChannel {

  String CANCEL_OUTPUT = "cancel";

  @Output(CancellingChannel.CANCEL_OUTPUT)
  MessageChannel cancellingBooking();

}