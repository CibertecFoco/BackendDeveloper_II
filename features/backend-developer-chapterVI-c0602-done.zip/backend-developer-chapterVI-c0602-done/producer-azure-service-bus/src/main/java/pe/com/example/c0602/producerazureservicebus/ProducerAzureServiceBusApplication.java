package pe.com.example.c0602.producerazureservicebus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducerAzureServiceBusApplication {

  public static void main(String[] args) {
    SpringApplication.run(ProducerAzureServiceBusApplication.class, args);
  }

}
