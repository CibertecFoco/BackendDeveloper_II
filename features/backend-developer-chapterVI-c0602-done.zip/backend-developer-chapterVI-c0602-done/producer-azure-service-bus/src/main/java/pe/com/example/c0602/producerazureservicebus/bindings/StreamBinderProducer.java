package pe.com.example.c0602.producerazureservicebus.bindings;

import java.util.Map;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Component;
import pe.com.example.c0602.producerazureservicebus.messaging.CancellingChannel;
import pe.com.example.c0602.producerazureservicebus.models.fn03.BikeBookingRequest;

/**
 * Este clase realiza el envío del payload enviado a través del request http al controlador de esta
 * aplicación. Por cuestiones didactas se reutiliza las interfaces que provee spring cloud stream
 * para el caso de producir y recibir los mensajes a través de services bus.
 */
@Component
@EnableBinding(value = {Source.class, CancellingChannel.class})
public class StreamBinderProducer {

  private Source source;

  private MessageChannel cancel;

  public StreamBinderProducer(Source source, MessageChannel cancel) {
    this.source = source;
    this.cancel = cancel;
  }

  /**
   * Este método realiza el envio del mensaje al Azure service bus a topic configurado en el archivo
   * application.yml.
   *
   * @param payload
   * @return Map<String, String>
   */
  public Map<String, String> sendMessageToServiceBusCreatingTopic(BikeBookingRequest payload) {
    Message<BikeBookingRequest> message = new GenericMessage<>(payload);
    source.output().send(message);
    return Map.of("status", "sent");
  }

  /**
   * Este método realiza el envío del identificador del alquiler para poder realizar la cancelación de
   * dicho alquiler. Para este procedimiento se define un MessageChannel personalizado para realizar
   * el envío de la solicitud.
   *
   * @param bookingId identificador del alquiler
   * @return Map<String, String>
   */
  public Map<String, String> sendMessageToServiceBusCancellingTopic(int bookingId) {
    cancel.send(new GenericMessage<>(Map.of("bookingId", bookingId)));
    return Map.of("status", "sent");
  }

}
