package pe.com.example.c0602.producerazureservicebus.models.fn03;

public class BookingStationVo {

  private StationVo station;

  /**
   * @return the station
   */
  public StationVo getStation() {
    return station;
  }

  /**
   * @param station the station to set
   */
  public void setStation(StationVo station) {
    this.station = station;
  }

}