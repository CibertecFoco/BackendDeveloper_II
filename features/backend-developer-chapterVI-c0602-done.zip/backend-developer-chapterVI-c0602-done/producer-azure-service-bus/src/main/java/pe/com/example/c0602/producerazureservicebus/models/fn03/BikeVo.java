package pe.com.example.c0602.producerazureservicebus.models.fn03;

public class BikeVo {

  private String code;

  /**
   * @return the code
   */
  public String getCode() {
    return code;
  }

  /**
   * @param code the code to set
   */
  public void setCode(String code) {
    this.code = code;
  }

}