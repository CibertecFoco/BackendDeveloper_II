package pe.com.example.c0602.consumerazureservicebus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumerAzureServiceBusApplication {

  public static void main(String[] args) {
    SpringApplication.run(ConsumerAzureServiceBusApplication.class, args);
  }

}
