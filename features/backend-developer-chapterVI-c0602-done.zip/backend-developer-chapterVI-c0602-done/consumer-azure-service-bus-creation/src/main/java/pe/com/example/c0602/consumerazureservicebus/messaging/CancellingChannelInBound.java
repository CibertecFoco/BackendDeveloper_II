package pe.com.example.c0602.consumerazureservicebus.messaging;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.SubscribableChannel;

public interface CancellingChannelInBound {

  String CANCEL_INPUT = "cancel";

  @Output(CancellingChannelInBound.CANCEL_INPUT)
  SubscribableChannel cancellingBooking();

}