Implementando Topics con Pub & Sub con Azure Service Bus
=========================================================


Casos:
-------

![Azure Serivce Bus](./imgs/azure-service-bus.svg)

Pasos:
-------

Links:
-------

- https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-messaging-overview
- https://docs.microsoft.com/en-us/azure/event-grid/compare-messaging-services?toc=https%3A%2F%2Fdocs.microsoft.com%2Fen-us%2Fazure%2Fservice-bus-messaging%2Ftoc.json&bc=https%3A%2F%2Fdocs.microsoft.com%2Fen-us%2Fazure%2Fbread%2Ftoc.json
- https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-java-how-to-use-topics-subscriptions
-  https://github.com/Azure/azure-service-bus/tree/master/samples/Java/azure-servicebus
- https://github.com/microsoft/spring-cloud-azure/tree/release/1.1.0.RC3/spring-cloud-azure-samples
- https://cloud.spring.io/spring-cloud-static/spring-cloud-stream/2.2.1.RELEASE/spring-cloud-stream.html#_destination_bindings

