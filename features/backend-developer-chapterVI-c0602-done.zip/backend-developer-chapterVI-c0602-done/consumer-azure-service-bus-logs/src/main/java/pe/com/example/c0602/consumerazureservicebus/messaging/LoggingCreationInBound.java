package pe.com.example.c0602.consumerazureservicebus.messaging;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface LoggingCreationInBound {

  String LOGGING_INPUT = "logs-creation";

  @Input(LoggingCreationInBound.LOGGING_INPUT)
  SubscribableChannel loggingCreation();

}