package pe.com.example.c0602.consumerazureservicebus.models.fn09;

import java.io.Serializable;

public class BikeBookingVo implements Serializable {

  /**
   *
   */
  private static final long serialVersionUID = 7058248119717956240L;

  private int bookingId;

  /**
   * @return the bookingId
   */
  public int getBookingId() {
    return bookingId;
  }

  /**
   * @param bookingId the bookingId to set
   */
  public void setBookingId(int bookingId) {
    this.bookingId = bookingId;
  }

  @Override
  public String toString() {
    return String.format("{bookingId: %d }", this.getBookingId());
  }

}