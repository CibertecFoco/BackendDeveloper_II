package pe.com.example.c0602.consumerazureservicebus.bindings;

import com.microsoft.azure.spring.integration.core.AzureHeaders;
import com.microsoft.azure.spring.integration.core.api.Checkpointer;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Header;
import pe.com.example.c0602.consumerazureservicebus.messaging.LoggingCancellingInBound;
import pe.com.example.c0602.consumerazureservicebus.messaging.LoggingCreationInBound;
import pe.com.example.c0602.consumerazureservicebus.models.fn03.BikeBookingRequest;
import pe.com.example.c0602.consumerazureservicebus.models.fn09.BikeBookingVo;

/**
 * Clase Listener, que permite subscribirnos a topic subscriptions para poder obtener los datos
 * producidos por la aplicación.
 *
 */
@EnableBinding(value = {LoggingCreationInBound.class, LoggingCancellingInBound.class})
public class StreamBinderConsumerTopic {

  private static final Logger log = LoggerFactory.getLogger(StreamBinderConsumerTopic.class);

  /**
   * método que recibe el payload BikeBookingRequest (Json), para esté @listener se subscribe mediante
   * la configuración en el archivo application.yml input.logs.subs
   *
   * @param payload
   * @param checkpointer
   */
  @StreamListener(LoggingCreationInBound.LOGGING_INPUT)
  private void handlerLoggingCreation(BikeBookingRequest payload,
      @Header(AzureHeaders.CHECKPOINTER) Checkpointer checkpointer) {
    log.info("New log payload received: {} BikeBooking", payload);
    checkpointer.success().handle((r, ex) -> {
      if (ex == null) {
        log.info("Message {} successfully checkpointer", r);
      }
      return null;
    });
  }

  /**
   * método para logear el bookingId que se está cancelando.
   *
   * @param bookingCancel
   */
  @StreamListener(LoggingCancellingInBound.LOGGING_INPUT)
  private void handlerLoggingCancelling(BikeBookingVo bookingCancel) {
    log.info("New Log cancelling received: {}", bookingCancel);
  }

}
