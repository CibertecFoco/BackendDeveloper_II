package pe.com.example.c0602.consumerazureservicebus.messaging;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.SubscribableChannel;

public interface LoggingCancellingInBound {

  String LOGGING_INPUT = "logs-cancelling";

  @Input(LoggingCancellingInBound.LOGGING_INPUT)
  SubscribableChannel loggingCancelling();

}